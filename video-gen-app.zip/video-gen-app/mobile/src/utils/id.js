/** Short unique id for locally stored items. */
export const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
